package gymmembershipframeapp;

import za.ac.tut.ui.GymMembershipFrame;

/**
 *
 * @author MemaniV
 */
public class GymMembershipFrameApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // instantiation
        new GymMembershipFrame();
    }
    
}

