package za.ac.tut.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import za.ac.tut.membership.Member;

/**
 *
 * @author MemaniV
 */
public class GymMembershipFrame extends JFrame {
    //panels
    private JPanel headingPnl;
    private JPanel clientPnl;
    private JPanel namePnl;
    private JPanel surnamePnl;
    private JPanel idNoPnl;
    private JPanel genderPnl;
    private JPanel contractsPnl;
    private JPanel personalTrainerOptionPnl;
    private JPanel membershipPnl;
    private JPanel commentsPnl;
    private JPanel headingClientCombinedPnl;
    private JPanel membershipCommentsCombinedPnl;
    private JPanel mainPnl;
    
    //labels
    private JLabel headingLbl;
    private JLabel nameLbl;
    private JLabel surnameLbl;
    private JLabel idNoLbl;
    private JLabel genderLbl;
    private JLabel personalTrainerLbl;
    private JLabel contractTypeLbl;
    
    //textfields
    private JTextField nameTxtFld;
    private JTextField surnameTxtFld;
    private JTextField idNoTxtFld;
    
    //combobox
    private JComboBox genderComboBox;
    
    //radio buttons
    private JRadioButton monthToMonthRadBtn;
    private JRadioButton sixMonthsRadBtn;
    private JRadioButton annualRadBtn;
    
    //checkbox
    private JCheckBox personalTrainerChkBx;
    
    //buttongroup
    private ButtonGroup btnGrp;
    
    //textarea
    private JTextArea commentsArea;
    
    //scrollpane
    private JScrollPane scrollableTxtArea;
       
    //menubar
    private JMenuBar menuBar;
    
    //menu items
    private JMenuItem openFileMenuItem;
    private JMenuItem viewFileMenuItem;
    private JMenuItem clearMenuItem;
    private JMenuItem exitMenuItem;
    private JMenuItem searchBntItem;
    private JMenuItem DeleteBtnItem;
    
    
    //menu
    private JMenu fileMenu;
          
    //construct the gui
    public GymMembershipFrame(){
        //set the frame
        setTitle("Gym membership");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JFrame.setDefaultLookAndFeelDecorated(true);
        
        //menu bar
        menuBar = new JMenuBar();
        
        //menu 
        fileMenu = new JMenu("File");
        
        //menu item
        openFileMenuItem = new JMenuItem("Register member...");
        openFileMenuItem.addActionListener(new RegisterBtnListener());
        
        viewFileMenuItem = new JMenuItem("Display members...");
        viewFileMenuItem.addActionListener(new DisplayBtnListener());
        
        clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(new ClearBtnListener());
        
        exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(new ExitBtnListener());
        
        searchBntItem = new JMenuItem("Search");
        searchBntItem.addActionListener(new SearchButton());
        
        DeleteBtnItem = new JMenuItem("Detele");
        DeleteBtnItem.addActionListener(new DeleteButton());
        
        //add items to the file menu
        fileMenu.add(openFileMenuItem);
        fileMenu.add(viewFileMenuItem);
        fileMenu.add(searchBntItem);
        fileMenu.add(DeleteBtnItem);
        fileMenu.addSeparator();
        fileMenu.add(clearMenuItem);
        fileMenu.add(exitMenuItem);        
        
        menuBar.add(fileMenu);
                
        //create panels
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        clientPnl = new JPanel(new GridLayout(4,1,1,1));
        clientPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Client details"));
        
        namePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        surnamePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        idNoPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        contractsPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        personalTrainerOptionPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        membershipPnl = new JPanel(new GridLayout(2,1,1,1));
        membershipPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Contract options"));
        
        commentsPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));

        headingClientCombinedPnl = new JPanel(new BorderLayout());
        membershipCommentsCombinedPnl = new JPanel(new BorderLayout());
        mainPnl = new JPanel(new BorderLayout());
        
        //create labels
        headingLbl = new JLabel("Membership Form");
        headingLbl.setFont(new Font(Font.SANS_SERIF, Font.ITALIC + Font.BOLD, 20));
        headingLbl.setForeground(Color.BLUE);
        headingLbl.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
        
        nameLbl = new JLabel("Name:       ");
        surnameLbl = new JLabel("Surname: ");
        idNoLbl = new JLabel("Id no:         ");
        genderLbl = new JLabel("Gender:     ");     
        contractTypeLbl = new JLabel("Type of contract: ");
        personalTrainerLbl = new JLabel("Select the checkbox if you need a personal trainer ");
        
        //create textfields
        nameTxtFld = new JTextField(10);
        surnameTxtFld = new JTextField(10);
        idNoTxtFld = new JTextField(10);
        
        //create combobox
        genderComboBox = new JComboBox();
        genderComboBox.addItem("Male");
        genderComboBox.addItem("Female");

        //create radio buttons
        monthToMonthRadBtn = new JRadioButton("Month-to-month");
        sixMonthsRadBtn = new JRadioButton("Six months");
        annualRadBtn = new JRadioButton("Annual");  
        
        //create csheck box
        personalTrainerChkBx = new JCheckBox();
        
        //create button group
        btnGrp = new ButtonGroup();
        btnGrp.add(monthToMonthRadBtn);
        btnGrp.add(sixMonthsRadBtn);
        btnGrp.add(annualRadBtn);
        
        //create text area
        commentsArea = new JTextArea(15,50);
        commentsArea.setEditable(false);
        commentsArea.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Member(s) details"));
        
        scrollableTxtArea = new JScrollPane(commentsArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
               
        //add components to panels
        headingPnl.add(headingLbl); //--> first collective panel
        
        namePnl.add(nameLbl);
        namePnl.add(nameTxtFld);
        
        surnamePnl.add(surnameLbl);
        surnamePnl.add(surnameTxtFld);
        
        idNoPnl.add(idNoLbl);
        idNoPnl.add(idNoTxtFld);
        
        genderPnl.add(genderLbl);
        genderPnl.add(genderComboBox);
        
        clientPnl.add(namePnl); //---> second collective panel
        clientPnl.add(surnamePnl);
        clientPnl.add(idNoPnl);
        clientPnl.add(genderPnl);
        
        headingClientCombinedPnl.add(headingPnl, BorderLayout.NORTH);
        headingClientCombinedPnl.add(clientPnl, BorderLayout.CENTER);
        
        contractsPnl.add(contractTypeLbl);
        contractsPnl.add(monthToMonthRadBtn); //---> third collective panel
        contractsPnl.add(sixMonthsRadBtn);
        contractsPnl.add(annualRadBtn);
        
        personalTrainerOptionPnl.add(personalTrainerLbl);
        personalTrainerOptionPnl.add(personalTrainerChkBx);
        
        membershipPnl.add(contractsPnl);
        membershipPnl.add(personalTrainerOptionPnl);
        
        commentsPnl.add(scrollableTxtArea); //---> fourth collective panel
        
        membershipCommentsCombinedPnl.add(membershipPnl, BorderLayout.NORTH);
        membershipCommentsCombinedPnl.add(commentsPnl, BorderLayout.CENTER);
                
        mainPnl.add(headingClientCombinedPnl, BorderLayout.NORTH);
        mainPnl.add(membershipCommentsCombinedPnl, BorderLayout.CENTER);
        
        add(mainPnl);
      
        pack();
        
        setResizable(false);
        
        //add 
        setJMenuBar(menuBar);
        
        setVisible(true);
    }
    
    //helper method for clearing fields
    private void clearFields(){
        //clear the fields
        nameTxtFld.setText("");
        surnameTxtFld.setText("");
        idNoTxtFld.setText("");
        personalTrainerChkBx.setSelected(false);
        btnGrp.clearSelection();
        commentsArea.setText("");
            
        //set focus back to the nsme text field
        nameTxtFld.setFocusable(true);
    }

    private class DeleteButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) 
{
    JFileChooser FC = new JFileChooser();
    File file;
    File tempFile = new File("dataa.txt");
    int val;
    String data;
    val = FC.showOpenDialog(GymMembershipFrame.this);
    if (val == JFileChooser.APPROVE_OPTION) {
        try {
            file = FC.getSelectedFile();
            BufferedReader BFR = new BufferedReader(new FileReader(file));
            BufferedWriter BWT = new BufferedWriter(new FileWriter(tempFile));

            boolean matchFound = false;

            while ((data = BFR.readLine()) != null) {
                String cas[] = data.split(",");
                Member mb = new Member(cas[0], cas[1], cas[2], cas[3], cas[4], Boolean.parseBoolean(cas[5]));

                if (!cas[0].trim().equalsIgnoreCase(nameTxtFld.getText().trim())) {
                    BWT.write(data);
                    BWT.newLine();
                } else {
                    matchFound = true;
                }
            }

            BFR.close();
            BWT.close();

            if (matchFound) {
                file.delete();
                tempFile.renameTo(file);
                JOptionPane.showMessageDialog(GymMembershipFrame.this, "Member Deleted");
            } else {
                tempFile.delete(); // Clean up temporary file if no match found
                JOptionPane.showMessageDialog(GymMembershipFrame.this, "Member not found");
            }
        } catch (IOException EA) {
            JOptionPane.showMessageDialog(GymMembershipFrame.this, "Ops");
        }
    }}
}

    private class SearchButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser FC = new JFileChooser();
            File file;
            int val;
            String data;
             val = FC.showOpenDialog(GymMembershipFrame.this);
             boolean vel = false;
             
             if(val == JFileChooser.APPROVE_OPTION)
             {
               try
               {
                 file = FC.getSelectedFile();
                 BufferedReader BFR = new BufferedReader(new FileReader(file));
                 
                 while((data = BFR.readLine())!= null)
                 {
                   String temp[] = data.split(",");
                   
                   Member mb =  new Member(temp[0],temp[1],temp[2],temp[3],temp[4],Boolean.parseBoolean(temp[5]));
                 if(temp[0].trim().equalsIgnoreCase(nameTxtFld.getText()))
                 {
                 commentsArea.setText(mb.toString());
                 JOptionPane.showMessageDialog(GymMembershipFrame.this, "FOUND");
                 vel = true;
                 }
                  
                 }
                 if(vel == false)
                  {
                  
                  JOptionPane.showMessageDialog(GymMembershipFrame.this, "Member Not Registered");
                  }
               }
               catch(IOException kc)
               {
               JOptionPane.showMessageDialog(GymMembershipFrame.this, "ops");
               }
             
             
             
             
             }
        }

       
    }
    
    //anonymous class for registering a member. It handles the REGISTER button.
    private class RegisterBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {      
            //declare local variables
            String name, surname, idNo, gender, contractType;
            Boolean isPersonalTrainerSelected;
            Member member;
            JFileChooser fc;
            int val;
            File file;
            BufferedWriter bw;
            
            //read data from the fields
            name = nameTxtFld.getText();
            surname = surnameTxtFld.getText();
            idNo = idNoTxtFld.getText();
            gender = (String)genderComboBox.getSelectedItem();
            isPersonalTrainerSelected = personalTrainerChkBx.isSelected();
            contractType =  "Month-to-month";

            if(sixMonthsRadBtn.isSelected()){
                contractType = "Six months";
            } else {
                if(annualRadBtn.isSelected()){
                    contractType = "Annual";
                }
            }
            
            //create a member
            member = new Member(name, surname, idNo, gender, contractType, isPersonalTrainerSelected);

            //create a file chooser
            fc = new JFileChooser();
            
            //show the save dialog
            val = fc.showSaveDialog(GymMembershipFrame.this);
                
            if(val == JFileChooser.APPROVE_OPTION){
                try {
                    
                    //get the selected file
                    file = fc.getSelectedFile();
                    
                    //open  the writing stream
                    bw = new BufferedWriter(new FileWriter(file, true));
                    
                    //write data to the file
                    bw.write(member.toString());
                    
                    //move the cursor to the newline after writing data
                    bw.newLine();
                    
                    //close the stream
                    bw.close();
                    
                    //clear the fields
                    clearFields();
                    
                    //confirmation dialog
                    JOptionPane.showMessageDialog(GymMembershipFrame.this, "Member registered");
                } catch (IOException ex) {
                    Logger.getLogger(GymMembershipFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                JOptionPane.showMessageDialog(GymMembershipFrame.this, "The if statement failed.The returned value is " + val);
            }
        }
    }
    
    //anonymous class for displaying the file contents on the text area. It handles the DISPLAY MEMBERS button.
    private class DisplayBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            //declare local variables
            BufferedReader br;
            String data, record = "";
            JFileChooser fc;
            int val;
            File file;
            
            //create a file chooser
            fc = new JFileChooser();
            
            //open a file dialog
            val = fc.showOpenDialog(GymMembershipFrame.this);

            //check if the returned value is n approved one
            if(val == JFileChooser.APPROVE_OPTION){
                try {
                    //get selected file
                    file = fc.getSelectedFile();
                    
                    //open a reading stream
                    br = new BufferedReader(new FileReader(file));
                    
                    //read the file until end of file
                    while((data = br.readLine())!=null){
                        //concatenate data
                        record = record + data + "\n";
                    }
                    
                    //close the reading stream
                    br.close();
                    
                    //append the data on the text area
                    commentsArea.setText(record);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(GymMembershipFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(GymMembershipFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
        //anonnymous class for clearing the fields. It handles the CLEAR button.
    private class ClearBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            //invoke a method to clear the fields
            clearFields();
        }
    }

    //anonymous class for exiting the application. It handles the EXIT button.    
    private class ExitBtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            //exit the application
            System.exit(0);
        }
    }

}


